export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:.
./leadcoind -server -daemon -datadir=./data -maxconnections=1024
